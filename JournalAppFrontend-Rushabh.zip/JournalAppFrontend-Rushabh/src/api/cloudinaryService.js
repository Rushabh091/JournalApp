const CLOUD_NAME = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || "diiondxny";
const UPLOAD_PRESET = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET;
const UPLOAD_FOLDER = import.meta.env.VITE_CLOUDINARY_UPLOAD_FOLDER || "journal-app/profile";

const CLOUDINARY_UPLOAD_URL = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`;

export const uploadProfilePhoto = async (file) => {
  if (!file) {
    throw new Error("No file selected");
  }

  if (!UPLOAD_PRESET) {
    throw new Error("Missing VITE_CLOUDINARY_UPLOAD_PRESET");
  }

  const body = new FormData();
  body.append("file", file);
  body.append("upload_preset", UPLOAD_PRESET);
  body.append("folder", UPLOAD_FOLDER);

  const response = await fetch(CLOUDINARY_UPLOAD_URL, {
    method: "POST",
    body,
  });

  if (!response.ok) {
    throw new Error("Cloudinary upload failed");
  }

  const data = await response.json();
  return data.secure_url;
};
