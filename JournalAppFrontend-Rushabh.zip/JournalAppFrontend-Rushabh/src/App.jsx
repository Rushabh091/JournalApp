import { Route, Routes } from "react-router-dom";
import "./App.css";
import Dashboard from "./pages/Dashboard.jsx";
import Dashboard1 from "./pages/Dashboard.jsx";
import MainLayout from "./components/MainLayout.jsx";
import AddJournal from "./pages/AddJournal.jsx";
import JournalEntries from "./pages/JournalEntries.jsx";
import JournalDetail from "./pages/JournalDetail.jsx";
import Profile from "./pages/Profile.jsx";
import SignIn from "./pages/SignIn.jsx";
import SignUp from "./pages/SignUp.jsx";
import ForgotPassword from "./pages/ForgotPassword";
import { AuthProvider } from "./auth/AuthContext";
import RequireAuth from "./auth/RequireAuth";
import { message } from "antd";

message.config({
  top: 20,
  duration: 2,
  maxCount: 3,
});

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route
          path="/"
          element={
            <RequireAuth>
              <MainLayout />
            </RequireAuth>
          }
        >
          <Route index element={<Dashboard />} />
          {/* <Route path="/dashboard1" element={<Dashboard1 />} /> */}
          <Route path="/journals" element={<AddJournal />} />
          <Route path="/entries" element={<JournalEntries />} />
          <Route path="entries/:id" element={<JournalDetail />} />
          <Route path="/profile" element={<Profile />} />


        </Route>

        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />

      </Routes>
    </AuthProvider>
  );
}

export default App;
