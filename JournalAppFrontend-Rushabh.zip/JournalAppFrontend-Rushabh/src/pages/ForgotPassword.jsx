import { Form, Input, Button, Typography, message } from "antd";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthLayout from "../components/AuthLayout";
import { useAuth } from "../auth/AuthContext";
import PasswordStrength from "../components/PasswordStrength";

const { Title, Text } = Typography;

const ForgotPassword = () => {
  const { sendForgotOtp, verifyForgotOtp, changePassword } = useAuth();
  const [step, setStep] = useState(0);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSendOtp = async ({ email }) => {
    try {
      setLoading(true);
      await sendForgotOtp(email);
      setEmail(email);
      message.success("OTP sent");
      setStep(1);
    } catch (err) {
      message.error(err?.response?.data || "User not found");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async ({ otp }) => {
    try {
      setLoading(true);
      await verifyForgotOtp(email, otp);
      message.success("OTP verified");
      setStep(2);
    } catch {
      message.error("Invalid OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async ({ password }) => {
    try {
      setLoading(true);
      await changePassword(email, password);
      message.success("Password changed successfully");
      setTimeout(() => navigate("/signin"), 1500);
    } catch {
      message.error("Failed to change password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <Title level={3} style={{ textAlign: "center" }}>Forgot Password</Title>

      {step === 0 && (
        <Form onFinish={handleSendOtp} layout="vertical">
          <Form.Item name="email" label="Email" rules={[{ required: true, type: "email" }]}>
            <Input size="large" />
          </Form.Item>
          <Button block type="primary" htmlType="submit" loading={loading}>Send OTP</Button>
        </Form>
      )}

      {step === 1 && (
        <Form onFinish={handleVerifyOtp} layout="vertical">
          <Form.Item name="otp" label="OTP" rules={[{ required: true }]}>
            <Input size="large" />
          </Form.Item>
          <Button block type="primary" htmlType="submit" loading={loading}>Verify OTP</Button>
        </Form>
      )}

      {step === 2 && (
        <Form onFinish={handleChangePassword} layout="vertical">
          <Form.Item name="password" label="New Password" rules={[{ required: true }]}>
            <Input.Password size="large" onChange={(e) => setPassword(e.target.value)} />
          </Form.Item>

          <PasswordStrength password={password} />

          <Form.Item
            name="confirm"
            label="Confirm Password"
            dependencies={["password"]}
            rules={[
              { required: true },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue("password") === value) return Promise.resolve();
                  return Promise.reject(new Error("Passwords do not match"));
                },
              }),
            ]}
          >
            <Input.Password size="large" />
          </Form.Item>

          <Button block type="primary" htmlType="submit" loading={loading}>Change Password</Button>
        </Form>
      )}

      {step === 3 && (
        <Text type="success" style={{ textAlign: "center", display: "block" }}>
          Password changed successfully!
        </Text>
      )}
    </AuthLayout>
  );
};

export default ForgotPassword;
