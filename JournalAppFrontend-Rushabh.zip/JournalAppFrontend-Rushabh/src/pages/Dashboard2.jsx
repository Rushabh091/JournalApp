import React, { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import "./Dashboard.css";
import MoodScoreCard from "../components/MoodScoreCard";

const Dashboard = () => {
  const token = localStorage.getItem("accessToken");

  const [fullName, setFullName] = useState("");
  const [text, setText] = useState("");
  const [index, setIndex] = useState(0);
  const [moveTop, setMoveTop] = useState(false);
  const [showContent, setShowContent] = useState(false);

  const [chartData, setChartData] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [score, setScore] = useState(null);

  const [allAnalysis, setAllAnalysis] = useState([]);
  const [showPopup, setShowPopup] = useState(false);

  // Always have fallback chart
  const emptyChart = [
    { name: "Mon", value: 0 },
    { name: "Tue", value: 0 },
    { name: "Wed", value: 0 },
    { name: "Thu", value: 0 },
    { name: "Fri", value: 0 },
    { name: "Sat", value: 0 },
    { name: "Sun", value: 0 },
  ];

  const fetchUserDetails = async () => {
    try {
      const res = await fetch("http://localhost:8080/user/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      setFullName(`${data.firstName || ""} ${data.lastName || ""}`.trim());
    } catch (e) {
      console.error("User fetch failed", e);
    }
  };

  const fetchAnalysis = async () => {
    try {
      const res = await fetch("http://localhost:8080/analysis/last-week", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();

      // No journal case
      if (
        data?.patternsObserved?.length === 1 &&
        data.patternsObserved[0] === "No journal entries for last week"
      ) {
        setAnalysis({ noData: true });
        setChartData([]);
        return;
      }

      setAnalysis(data);
      setScore(data.overAllScore);

      const daily = data.daily || {};
      const formatted = Object.entries(daily).map(([day, obj]) => ({
        name: day.slice(0, 3),
        value: obj?.score ?? 0,
      }));

      setChartData(formatted);
    } catch (e) {
      console.error("Analysis fetch failed", e);
    }
  };

  const fetchAllAnalysis = async () => {
    try {
      const res = await fetch("http://localhost:8080/analysis/all", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error("API failed");

      const data = await res.json();

      if (!Array.isArray(data)) {
        console.error("Invalid response:", data);
        return;
      }

      setAllAnalysis(data);
      setShowPopup(true);
    } catch (err) {
      console.error("Popup failed", err);
    }
  };

  useEffect(() => {
    fetchUserDetails();
    fetchAnalysis();
  }, []);

  // Typing animation
  useEffect(() => {
    if (!fullName) return;
    if (index < fullName.length) {
      const t = setTimeout(() => {
        setText((p) => p + fullName[index]);
        setIndex((p) => p + 1);
      }, 50);
      return () => clearTimeout(t);
    } else {
      setTimeout(() => setMoveTop(true), 300);
      setTimeout(() => setShowContent(true), 700);
    }
  }, [index, fullName]);

  return (
  <div className="dashboard-wrapper">
    {/* Animated Welcome */}
    <div className={`welcome ${moveTop ? "top" : "center"}`}>
      Welcome, {text}
      <span className="cursor">|</span>
    </div>

    {/* Actual dashboard */}
    <div className={`dashboard-content ${showContent ? "show" : ""}`}>
      <main className="dashboard">
        <header className="dashboard-header">
          <p className="subtitle">
            Track your emotions. Discover patterns. Grow every week 🌱
          </p>
        </header>

        {/* Mood score */}
        <MoodScoreCard score={score ?? 0} />

        <section className="dashboard-grid">
          {/* Chart */}
          <div className="card">
            <h3>Mood Analytics (This Week)</h3>

            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={chartData.length ? chartData : emptyChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Line dataKey="value" strokeWidth={3} dot />
              </LineChart>
            </ResponsiveContainer>

            <div className="daily-row">
              {chartData.map((d) => (
                <div key={d.name} className="day-pill">
                  {d.name} <strong>{d.value}</strong>
                </div>
              ))}
            </div>
          </div>

          {/* Insights */}
          <div className="card">
            <h3>AI Weekly Insights</h3>

            {analysis?.noData ? (
              <>
                <p>No journal entries for last week.</p>
                <button
                  className="cta-btn"
                  onClick={() => (window.location.href = "/add-journal")}
                >
                  Write your first journal →
                </button>
              </>
            ) : (
              <>
                <div className="insight">
                  <h4>What affected you</h4>
                  <p>{analysis?.personalReflection}</p>
                </div>

                <div className="highlight">
                  💡 <strong>Focus</strong>
                  <p>{analysis?.motivation}</p>
                </div>

                <div className="next">
                  🎯 <strong>Next week</strong>
                  <p>{analysis?.nextWeekAction}</p>
                </div>
              </>
            )}

            <span className="see-all" onClick={fetchAllAnalysis}>
              See all analysis →
            </span>
          </div>
        </section>
      </main>
    </div>

    {/* Popup stays unchanged */}
    {showPopup && (
      <div className="popup-overlay" onClick={() => setShowPopup(false)}>
        <div className="popup-card" onClick={(e) => e.stopPropagation()}>
          <h2>All Analysis</h2>

          {allAnalysis.map((a, i) => (
            <div key={i} className="analysis-block">
              <div className="analysis-date">
                {new Date(a.createdAt).toLocaleDateString()}
              </div>
              <p>
                <strong>Score:</strong> {a.overAllScore}
              </p>
              <p>{a.personalReflection}</p>
            </div>
          ))}
        </div>
      </div>
    )}
  </div>
);
};

export default Dashboard;
