import React, { useState } from "react";
import { Card, Input, Button, message } from "antd";
import { useNavigate } from "react-router-dom";
import PageLoader from "../components/PageLoader";
import "./AddJournal.css";

const { TextArea } = Input;

const AddJournal = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async () => {
    if (!title.trim()) {
      return message.warning("Title is required");
    }

    try {
      setLoading(true);
      const minDelay = new Promise((resolve) => setTimeout(resolve, 800));

      const saveData = fetch("http://localhost:8080/journal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
        },
        body: JSON.stringify({ title, content }),
      });

      const [res] = await Promise.all([saveData, minDelay]);

      if (!res.ok) throw new Error();

      message.success("Journal added successfully");

      // Navigate to entries after success
      navigate("/entries");
    } catch {
      message.error("Failed to add journal");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <PageLoader minHeight={420} />;
  }

  return (
    <div className="add-journal-wrapper">
      <Card className="add-journal-card">
        <h1 className="add-title">New Journal Entry</h1>

        <Input
          placeholder="Enter title..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="add-input-title"
        />

        <TextArea
          rows={10}
          placeholder="Write your thoughts here..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="add-input-content"
        />

        <div className="add-actions">
          <Button
            type="primary"
            loading={loading}
            onClick={handleSubmit}
          >
            Save Entry
          </Button>

          <Button onClick={() => navigate("/entries")}>
            Cancel
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default AddJournal;
