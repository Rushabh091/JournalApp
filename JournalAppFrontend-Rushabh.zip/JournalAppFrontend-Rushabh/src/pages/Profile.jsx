import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Button, Input, Switch, message } from "antd";
import PageLoader from "../components/PageLoader";
import { uploadProfilePhoto } from "../api/cloudinaryService";
import "./Profile.css";

const buildFormState = (user = {}) => ({
  userName: user.userName || "",
  firstName: user.firstName || "",
  lastName: user.lastName || "",
  email: user.email || "",
  mobile: user.mobile || "",
  country: user.country || "",
  state: user.state || "",
  sentimentAnalysis: Boolean(user.sentimentAnalysis),
  password: "",
});

const getRoleLabels = (roles) => {
  if (!Array.isArray(roles)) return [];
  return roles
    .map((role) => {
      if (typeof role === "string") return role;
      if (role?.name) return role.name;
      if (role?.authority) return role.authority;
      if (role?.role) return role.role;
      return "";
    })
    .filter(Boolean);
};

const PHOTO_FIELDS = [
  "profilePhotoUrl",
  "profileImageUrl",
  "avatarUrl",
  "imageUrl",
  "photoUrl",
];

const Profile = () => {
  const token = localStorage.getItem("accessToken");
  const [profile, setProfile] = useState(null);
  const [formValues, setFormValues] = useState(buildFormState());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreviewUrl, setPhotoPreviewUrl] = useState("");

  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true);
      const minDelay = new Promise((resolve) => setTimeout(resolve, 800));
      const fetchData = fetch("http://localhost:8080/user/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const [response] = await Promise.all([fetchData, minDelay]);
      if (!response.ok) throw new Error("Profile fetch failed");
      const data = await response.json();
      setProfile(data);
      setFormValues(buildFormState(data));
    } catch {
      message.error("Failed to load profile");
      setProfile(null);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const displayName = useMemo(() => {
    const fullName = `${profile?.firstName || ""} ${profile?.lastName || ""}`.trim();
    return fullName || profile?.userName || "User";
  }, [profile]);

  const initials = useMemo(() => {
    const source = `${profile?.firstName || ""} ${profile?.lastName || ""}`.trim() || profile?.userName || "U";
    const parts = source.split(/\s+/).filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return source.slice(0, 2).toUpperCase();
  }, [profile]);

  const roles = useMemo(() => getRoleLabels(profile?.roles), [profile]);
  const locationText = [profile?.country, profile?.state].filter(Boolean).join(" / ") || "-";
  const profileStatus = profile?.enabled === false ? "Inactive" : "Active";
  const detectedPhotoField = useMemo(() => {
    return PHOTO_FIELDS.find((field) =>
      Object.prototype.hasOwnProperty.call(profile || {}, field)
    );
  }, [profile]);

  const persistedPhotoUrl = useMemo(() => {
    const knownField = detectedPhotoField;
    if (knownField && profile?.[knownField]) {
      return profile[knownField];
    }

    for (const field of PHOTO_FIELDS) {
      if (profile?.[field]) return profile[field];
    }

    return "";
  }, [detectedPhotoField, profile]);

  const renderedPhotoUrl = photoPreviewUrl || persistedPhotoUrl;

  useEffect(() => {
    return () => {
      if (photoPreviewUrl) {
        URL.revokeObjectURL(photoPreviewUrl);
      }
    };
  }, [photoPreviewUrl]);

  const updateField = (field, value) => {
    setFormValues((prev) => ({ ...prev, [field]: value }));
  };

  const cancelEdit = () => {
    setFormValues(buildFormState(profile));
    setEditing(false);
    setPhotoFile(null);
    if (photoPreviewUrl) {
      URL.revokeObjectURL(photoPreviewUrl);
      setPhotoPreviewUrl("");
    }
  };

  const onPhotoSelect = (event) => {
    const selected = event.target.files?.[0];
    if (!selected) return;

    if (!selected.type.startsWith("image/")) {
      message.warning("Please select an image file");
      return;
    }

    if (selected.size > 5 * 1024 * 1024) {
      message.warning("Please select an image smaller than 5MB");
      return;
    }

    if (photoPreviewUrl) {
      URL.revokeObjectURL(photoPreviewUrl);
    }

    setPhotoFile(selected);
    setPhotoPreviewUrl(URL.createObjectURL(selected));
  };

  const saveProfile = async () => {
    if (!formValues.userName.trim()) return message.warning("Username is required");
    if (!formValues.email.trim()) return message.warning("Email is required");

    const payload = {
      userName: formValues.userName.trim(),
      firstName: formValues.firstName.trim(),
      lastName: formValues.lastName.trim(),
      email: formValues.email.trim(),
      mobile: formValues.mobile.trim(),
      country: formValues.country.trim(),
      state: formValues.state.trim(),
      sentimentAnalysis: Boolean(formValues.sentimentAnalysis),
    };

    if (formValues.password.trim()) {
      payload.password = formValues.password.trim();
    }

    try {
      setSaving(true);
      let uploadedPhotoUrl = "";

      if (photoFile) {
        uploadedPhotoUrl = await uploadProfilePhoto(photoFile);
      }

      if (uploadedPhotoUrl && detectedPhotoField) {
        payload[detectedPhotoField] = uploadedPhotoUrl;
      }

      const body = new FormData();
      body.append("user", JSON.stringify(payload));

      if (uploadedPhotoUrl) {
        body.append("profilePhotoUrl", uploadedPhotoUrl);
      }

      const minDelay = new Promise((resolve) => setTimeout(resolve, 800));
      const fetchData = fetch("http://localhost:8080/user/profile", {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body,
      });

      const [response] = await Promise.all([fetchData, minDelay]);

      if (!response.ok) throw new Error("Profile update failed");

      const data = await response.json();
      const mergedProfile =
        uploadedPhotoUrl && !detectedPhotoField
          ? { ...data, profilePhotoUrl: uploadedPhotoUrl }
          : data;

      setProfile(mergedProfile);
      setFormValues(buildFormState(data));
      setPhotoFile(null);
      if (photoPreviewUrl) {
        URL.revokeObjectURL(photoPreviewUrl);
        setPhotoPreviewUrl("");
      }

      if (data?.userName) {
        localStorage.setItem("username", data.userName);
      }

      setEditing(false);

      if (uploadedPhotoUrl && !detectedPhotoField) {
        message.warning(
          "Photo uploaded to Cloudinary. Add a profile photo field in backend User model to persist URL in DB."
        );
      }

      message.success("Profile updated");
    } catch (error) {
      if (error?.message === "Missing VITE_CLOUDINARY_UPLOAD_PRESET") {
        message.error("Set VITE_CLOUDINARY_UPLOAD_PRESET in your frontend .env file");
      } else {
        message.error("Failed to update profile");
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <PageLoader minHeight={420} />;
  }

  if (!profile) {
    return (
      <div className="profile-page">
        <h1 className="profile-title">Profile</h1>
        <section className="profile-card profile-empty-state">
          <p>Unable to load your profile details.</p>
          <Button onClick={fetchProfile}>Retry</Button>
        </section>
      </div>
    );
  }

  return (
    <div className="profile-page">
      <h1 className="profile-title">Profile</h1>

      <section className="profile-card">
        <div className="profile-top-row">
          <div className="profile-avatar">
            {renderedPhotoUrl ? (
              <img src={renderedPhotoUrl} alt="Profile" />
            ) : (
              <span className="profile-avatar-fallback">{initials}</span>
            )}
          </div>

          <div className="profile-identity">
            <h2>{displayName}</h2>
            <p>@{profile.userName || "username"}</p>
          </div>

          <div className="profile-actions">
            {!editing ? (
              <Button className="profile-btn profile-btn-edit" onClick={() => setEditing(true)}>
                Edit Profile
              </Button>
            ) : (
              <>
                <Button className="profile-btn" onClick={cancelEdit}>
                  Cancel
                </Button>
                <Button
                  type="primary"
                  className="profile-btn profile-btn-save"
                  onClick={saveProfile}
                  loading={saving}
                >
                  Save Changes
                </Button>
              </>
            )}
          </div>
        </div>

        <hr className="profile-divider" />

        {!editing ? (
          <div className="profile-details-grid">
            <div className="profile-details-col">
              <div className="profile-row">
                <span>Full Name:</span>
                <strong>{displayName}</strong>
              </div>
              <div className="profile-row">
                <span>Username:</span>
                <strong>@{profile.userName || "-"}</strong>
              </div>
              <div className="profile-row">
                <span>Email:</span>
                <strong>{profile.email || "-"}</strong>
              </div>
              <div className="profile-row">
                <span>Mobile:</span>
                <strong>{profile.mobile || "-"}</strong>
              </div>
            </div>

            <div className="profile-details-col">
              <div className="profile-row">
                <span>Country / State:</span>
                <strong>{locationText}</strong>
              </div>
              <div className="profile-row profile-status-row">
                <span>Status:</span>
                <strong className={`profile-status-chip ${profileStatus === "Active" ? "active" : "inactive"}`}>
                  {profileStatus}
                </strong>
              </div>
              <div className="profile-row profile-role-row">
                <span>Roles:</span>
                <strong className="profile-role-list">
                  {roles.length ? (
                    roles.map((role) => (
                      <span className="profile-role-chip" key={role}>
                        {role}
                      </span>
                    ))
                  ) : (
                    <span className="profile-value-muted">-</span>
                  )}
                </strong>
              </div>
              <div className="profile-row profile-status-row">
                <span>Sentiment Analysis:</span>
                <strong className={`profile-status-chip ${profile.sentimentAnalysis ? "active" : "inactive"}`}>
                  {profile.sentimentAnalysis ? "Enabled" : "Disabled"}
                </strong>
              </div>
            </div>
          </div>
        ) : (
          <div className="profile-form-grid">
            <label className="profile-field">
              <span>Username</span>
              <Input
                value={formValues.userName}
                onChange={(event) => updateField("userName", event.target.value)}
                placeholder="Enter username"
              />
            </label>

            <label className="profile-field">
              <span>Email</span>
              <Input
                value={formValues.email}
                onChange={(event) => updateField("email", event.target.value)}
                placeholder="Enter email"
              />
            </label>

            <label className="profile-field">
              <span>First Name</span>
              <Input
                value={formValues.firstName}
                onChange={(event) => updateField("firstName", event.target.value)}
                placeholder="Enter first name"
              />
            </label>

            <label className="profile-field">
              <span>Last Name</span>
              <Input
                value={formValues.lastName}
                onChange={(event) => updateField("lastName", event.target.value)}
                placeholder="Enter last name"
              />
            </label>

            <label className="profile-field">
              <span>Mobile</span>
              <Input
                value={formValues.mobile}
                onChange={(event) => updateField("mobile", event.target.value)}
                placeholder="Enter mobile"
              />
            </label>

            <label className="profile-field">
              <span>Country</span>
              <Input
                value={formValues.country}
                onChange={(event) => updateField("country", event.target.value)}
                placeholder="Enter country"
              />
            </label>

            <label className="profile-field">
              <span>State</span>
              <Input
                value={formValues.state}
                onChange={(event) => updateField("state", event.target.value)}
                placeholder="Enter state"
              />
            </label>

            <label className="profile-field">
              <span>New Password (Optional)</span>
              <Input.Password
                value={formValues.password}
                onChange={(event) => updateField("password", event.target.value)}
                placeholder="Leave blank to keep current password"
              />
            </label>

            <label className="profile-field profile-photo-field">
              <span>Profile Photo</span>
              <input
                className="profile-file-input"
                type="file"
                accept="image/*"
                onChange={onPhotoSelect}
              />
              <small className="profile-photo-help">
                {photoFile ? `Selected: ${photoFile.name}` : "Max size: 5MB"}
              </small>
            </label>

            <div className="profile-switch-row">
              <span>Sentiment Analysis</span>
              <Switch
                checked={Boolean(formValues.sentimentAnalysis)}
                onChange={(checked) => updateField("sentimentAnalysis", checked)}
              />
            </div>
          </div>
        )}
      </section>
    </div>
  );
};

export default Profile;
