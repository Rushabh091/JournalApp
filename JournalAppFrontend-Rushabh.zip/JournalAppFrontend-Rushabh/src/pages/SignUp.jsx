import React, { useState } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  Typography,
  Flex,
  Steps,
  message,
  Grid,
} from "antd";
import { Link, useNavigate } from "react-router-dom";
import { Country, State, City } from "country-state-city";
import { useAuth } from "../auth/AuthContext";
import PasswordStrength from "../components/PasswordStrength";
import AuthLayout from "../components/AuthLayout";

const { Title, Text } = Typography;
const { Option } = Select;
const { useBreakpoint } = Grid;

// Reusable step wrapper
const StepWrapper = ({ active, children }) => (
  <div style={{ display: active ? "block" : "none" }}>{children}</div>
);

const SignUp = () => {
  const { sendSignupOtp, verifySignupOtp, signup } = useAuth();
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const screens = useBreakpoint();
  const isMobile = !screens.sm;

  const [current, setCurrent] = useState(0);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const next = () => setCurrent((p) => p + 1);
  const prev = () => setCurrent((p) => p - 1);

  const handleSendOtp = async () => {
    const email = form.getFieldValue("email");
    if (!email) return message.error("Please enter email first");

    try {
      setLoading(true);
      await sendSignupOtp(email);
      setOtpSent(true);
      message.success("OTP sent to email");
    } catch (err) {
      message.error(err?.response?.data || "Failed to send OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    const email = form.getFieldValue("email");
    const otp = form.getFieldValue("otp");
    if (!otp) return message.error("Enter OTP");

    try {
      setLoading(true);
      await verifySignupOtp(email, otp);
      setOtpVerified(true);
      message.success("Email verified");
    } catch {
      message.error("Invalid OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleCountryChange = (code) => {
    form.setFieldsValue({ state: undefined, city: undefined });
    setStates(State.getStatesOfCountry(code));
    setCities([]);
  };

  const handleStateChange = (code) => {
    const country = form.getFieldValue("country");
    setCities(City.getCitiesOfState(country, code));
  };

  const onFinish = async (values) => {
    if (!otpVerified) return message.error("Verify email first");

    try {
      setLoading(true);
      console.log("FINAL PAYLOAD:", values);
      await signup(values);
      message.success("Account created!");
      navigate("/signin");
    } catch (err) {
      message.error(err?.response?.data || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout cardMaxWidth={640}>
        <Title level={3} style={{ textAlign: "center" }}>
          Create Account
        </Title>

        <Steps
          current={current}
          size={isMobile ? "small" : "default"}
          direction={isMobile ? "vertical" : "horizontal"}
          responsive={false}
          style={{ marginBottom: 24 }}
        >
          <Steps.Step title="Account" />
          <Steps.Step title="Personal" />
          <Steps.Step title="Location" />
        </Steps>

        <Form form={form} layout="vertical" onFinish={onFinish}>
          {/* STEP 0 */}
          <StepWrapper active={current === 0}>
            <Form.Item name="userName" label="Username" rules={[{ required: true }]}>
              <Input />
            </Form.Item>

            <Form.Item name="email" label="Email" rules={[{ required: true, type: "email" }]}>
              <Input />
            </Form.Item>

            <Form.Item name="password" label="Password" rules={[{ required: true }]}>
              <Input.Password onChange={(e) => setPassword(e.target.value)} />
            </Form.Item>

            <PasswordStrength password={password} />

            <Form.Item
              name="confirmPassword"
              label="Confirm Password"
              dependencies={["password"]}
              rules={[
                { required: true },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    return !value || getFieldValue("password") === value
                      ? Promise.resolve()
                      : Promise.reject(new Error("Passwords do not match"));
                  },
                }),
              ]}
            >
              <Input.Password />
            </Form.Item>

            {!otpSent ? (
              <Button block onClick={handleSendOtp} loading={loading}>
                Send OTP
              </Button>
            ) : !otpVerified ? (
              <>
                <Form.Item name="otp" label="OTP" rules={[{ required: true }]}>
                  <Input />
                </Form.Item>
                <Button block onClick={handleVerifyOtp} loading={loading}>
                  Verify OTP
                </Button>
              </>
            ) : (
              <Button block type="primary" onClick={next}>
                Continue
              </Button>
            )}
          </StepWrapper>

          {/* STEP 1 */}
          <StepWrapper active={current === 1}>
            <Form.Item name="firstName" label="First Name" rules={[{ required: true }]}>
              <Input />
            </Form.Item>

            <Form.Item name="lastName" label="Last Name">
              <Input />
            </Form.Item>

            <Form.Item name="mobile" label="Mobile" rules={[{ required: true }]}>
              <Input />
            </Form.Item>

            <Form.Item name="gender" label="Gender">
              <Select>
                <Option value="MALE">Male</Option>
                <Option value="FEMALE">Female</Option>
                <Option value="OTHER">Other</Option>
              </Select>
            </Form.Item>
          </StepWrapper>

          {/* STEP 2 */}
          <StepWrapper active={current === 2}>
            <Form.Item name="country" label="Country" rules={[{ required: true }]}>
              <Select showSearch onChange={handleCountryChange}>
                {Country.getAllCountries().map((c) => (
                  <Option key={c.isoCode} value={c.isoCode}>
                    {c.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item name="state" label="State" rules={[{ required: true }]}>
              <Select showSearch disabled={!states.length} onChange={handleStateChange}>
                {states.map((s) => (
                  <Option key={s.isoCode} value={s.isoCode}>
                    {s.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item name="city" label="City" rules={[{ required: true }]}>
              <Select showSearch disabled={!cities.length}>
                {cities.map((c) => (
                  <Option key={c.name} value={c.name}>
                    {c.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </StepWrapper>

          {/* NAVIGATION */}
          <Flex
            justify={current === 0 ? "flex-end" : "space-between"}
            gap={10}
            wrap="wrap"
          >
            {current > 0 && <Button onClick={prev}>Back</Button>}

            {current > 0 && current < 2 && (
              <Button type="primary" onClick={next}>
                Next
              </Button>
            )}

            {current === 2 && (
              <Button type="primary" htmlType="submit" loading={loading}>
                Create Account
              </Button>
            )}
          </Flex>
        </Form>

        <Text style={{ textAlign: "center", display: "block", marginTop: 16 }}>
          Already have an account? <Link to="/signin">Sign In</Link>
        </Text>
    </AuthLayout>
  );
};

export default SignUp;
