import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Card, Input, Button, message } from "antd";
import { EditOutlined, CheckOutlined, CloseOutlined } from "@ant-design/icons";
import "./JournalDetail.css";

const { TextArea } = Input;

const JournalDetail = () => {
  const { id } = useParams();

  const [entry, setEntry] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  useEffect(() => {
    fetch(`http://localhost:8080/journal/id/${id}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setEntry(data);
        setTitle(data.title);
        setContent(data.content);
      });
  }, [id]);

  const handleSave = async () => {
    try {
      const res = await fetch(`http://localhost:8080/journal/id/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
        },
        body: JSON.stringify({ title, content }),
      });

      if (!res.ok) throw new Error();

      const updated = await res.json();
      setEntry(updated);
      setIsEditing(false);
      message.success("Journal updated");
    } catch {
      message.error("Update failed");
    }
  };

  if (!entry) return null;

  return (
    <div className="journal-detail-wrapper">
      <Card className="journal-detail-card">
        {!isEditing && (
          <EditOutlined
            className="edit-icon"
            onClick={() => setIsEditing(true)}
          />
        )}

        {isEditing ? (
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="edit-title"
          />
        ) : (
          <h1 className="journal-title">{entry.title}</h1>
        )}
        
        <p className="journal-date">
          {new Date(entry.date).toDateString()}
        </p>
        <hr />  
        {isEditing ? (
          <>
            <TextArea
              rows={8}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="edit-content"
            />

            <div className="edit-actions">
              <Button
                type="primary"
                icon={<CheckOutlined />}
                onClick={handleSave}
              >
                Save
              </Button>
              <Button
                icon={<CloseOutlined />}
                onClick={() => {
                  setTitle(entry.title);
                  setContent(entry.content);
                  setIsEditing(false);
                }}
              >     
                Cancel
              </Button>
            </div>
          </>
        ) : (
          <p className="journal-content">{entry.content}</p>
        )}
      </Card>
    </div>
  );
};

export default JournalDetail;
    