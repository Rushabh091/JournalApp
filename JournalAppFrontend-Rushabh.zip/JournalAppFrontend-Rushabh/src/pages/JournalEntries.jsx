import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, Pagination, Empty, Popconfirm, message } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import PageLoader from "../components/PageLoader";
import "./JournalEntries.css";

const PAGE_SIZE = 9;

const JournalEntries = () => {
  const [journalEntries, setJournalEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);

  const navigate = useNavigate();

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
    });
  };

  const fetchJournalEntries = async () => {
    try {
      setLoading(true);

      const minDelay = new Promise((resolve) => setTimeout(resolve, 800));

      const fetchData = fetch("http://localhost:8080/journal", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
        },
      });

      const [response] = await Promise.all([fetchData, minDelay]);

      if (!response.ok) throw new Error();

      const data = await response.json();
      setJournalEntries(data);
    } catch {
      message.error("Failed to load journals");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJournalEntries();
  }, []);

  const deleteJournalEntry = async (id) => {
    try {
      const response = await fetch(
        `http://localhost:8080/journal/id/${id}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
          },
        }
      );

      if (!response.ok) throw new Error();
      setJournalEntries((prev) => {
        const updated = prev.filter((entry) => entry.id !== id);
        const maxPage = Math.max(1, Math.ceil(updated.length / PAGE_SIZE));
        setCurrentPage((p) => Math.min(p, maxPage));

        return updated;
      });

      message.success("Journal deleted");
    } catch {
      message.error("Delete failed");
    }
  };

  const startIndex = (currentPage - 1) * PAGE_SIZE;
  const paginatedData = journalEntries.slice(
    startIndex,
    startIndex + PAGE_SIZE
  );

  if (loading) {
    return <PageLoader />;
  }

  if (!journalEntries.length) {
    return <Empty description="No journal entries found" />;
  }

  return (
    <div className="journal-container">
      <div className="journal-grid">
        {paginatedData.map((entry) => (
          <Card
            key={entry.id}
            hoverable
            className="journal-card fade-in"
            onClick={() => navigate(`/entries/${entry.id}`)}
          >
            <div className="card-header">
              <div className="header-left">
                <h3 className="card-title">{entry.title}</h3>
                <span className="card-date">{formatDate(entry.date)}</span>
              </div>

              <Popconfirm
                title="Delete this journal?"
                description="This action cannot be undone."
                okText="Delete"
                okButtonProps={{ danger: true }}
                cancelText="Cancel"
                onConfirm={(e) => {
                  e?.stopPropagation();
                  deleteJournalEntry(entry.id);
                }}
              >
                <DeleteOutlined
                  className="delete-icon"
                  onClick={(e) => e.stopPropagation()}
                />
              </Popconfirm>
            </div>

            <hr />

            <p className="card-content">
              {entry.content.length > 120
                ? entry.content.slice(0, 120) + "..."
                : entry.content}
            </p>
          </Card>
        ))}
      </div>

      <div className="pagination-wrapper">
        <Pagination
          current={currentPage}
          pageSize={PAGE_SIZE}
          total={journalEntries.length}
          onChange={(page) => setCurrentPage(page)}
          showSizeChanger={false}
        />
      </div>
    </div>
  );
};

export default JournalEntries;
  
