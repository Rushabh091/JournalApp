import { Form, Input, Button, Typography, Checkbox, Flex, message } from "antd";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import AuthLayout from "../components/AuthLayout";
import { useAuth } from "../auth/AuthContext";

const { Title, Text } = Typography;

const SignIn = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [loading, setLoading] = useState(false);

  const onFinish = async (values) => {
    try {
      setLoading(true);

      await login({
        userNameOrEmail: values.email,
        password: values.password,
      });

      message.success("Login successful!");
      navigate("/");
    } catch (err) {
      message.error(err?.response?.data || err?.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <Title level={3} style={{ textAlign: "center" }}>
        Welcome Back
      </Title>

      <Text
        type="secondary"
        style={{ textAlign: "center", display: "block", marginBottom: 30 }}
      >
        Sign in to continue
      </Text>

      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item
          name="email"
          label="Username or Email"
          rules={[{ required: true }]}
        >
          <Input size="large" />
        </Form.Item>

        <Form.Item name="password" label="Password" rules={[{ required: true }]}>
          <Input.Password size="large" />
        </Form.Item>

        <Flex justify="space-between" style={{ marginBottom: 20 }}>
          <Checkbox>Remember me</Checkbox>
          <Link to="/forgot-password">Forgot password?</Link>
        </Flex>

        <Button type="primary" htmlType="submit" block loading={loading}>
          Sign In
        </Button>

        <Text style={{ display: "block", textAlign: "center", marginTop: 20 }}>
          Don&apos;t have an account? <Link to="/signup">Create account</Link>
        </Text>
      </Form>
    </AuthLayout>
  );
};

export default SignIn;
