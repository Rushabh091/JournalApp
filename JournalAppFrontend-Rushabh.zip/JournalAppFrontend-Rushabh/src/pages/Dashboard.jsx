import React, { useEffect, useMemo, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import MoodScoreCard from "../components/MoodScoreCard";
import "./Dashboard.css";

const WEEK_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const EMPTY_CHART = WEEK_DAYS.map((day) => ({ name: day, value: 0 }));
const DAY_ORDER = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
  "sunday",
];
const DAY_LABELS = {
  monday: "Mon",
  tuesday: "Tue",
  wednesday: "Wed",
  thursday: "Thu",
  friday: "Fri",
  saturday: "Sat",
  sunday: "Sun",
};
const DAY_ALIASES = {
  monday: "monday",
  mon: "monday",
  tuesday: "tuesday",
  tue: "tuesday",
  wednesday: "wednesday",
  wed: "wednesday",
  thursday: "thursday",
  thu: "thursday",
  friday: "friday",
  fri: "friday",
  saturday: "saturday",
  sat: "saturday",
  sunday: "sunday",
  sun: "sunday",
};

const normalizeDayKey = (day) => {
  const key = String(day || "").trim().toLowerCase();
  return DAY_ALIASES[key] || null;
};

const extractScore = (value) => {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  if (value && typeof value === "object") {
    const parsed = Number(value.score ?? value.value ?? 0);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  return 0;
};

const formatText = (value) => {
  if (Array.isArray(value)) return value.join(" ");
  return value || "";
};

const normalizeAnalysis = (raw) => {
  if (!raw || typeof raw !== "object") return null;
  return {
    ...raw,
    overAllScore: raw.overAllScore ?? raw.overall_score ?? 0,
    daily: raw.daily ?? raw.daily_scores ?? {},
    patternsObserved: raw.patternsObserved ?? raw.patterns_observed ?? "",
    personalReflection: raw.personalReflection ?? raw.personal_reflection ?? "",
    nextWeekExperiments:
      raw.nextWeekExperiments ??
      raw.next_week_experiments ??
      raw.nextWeekAction ??
      "",
    createdAt: raw.createdAt ?? raw.created_at ?? "",
  };
};

const buildChartData = (daily) => {
  if (!daily || typeof daily !== "object") return EMPTY_CHART;

  const mappedScores = {};
  Object.entries(daily).forEach(([day, value]) => {
    const normalizedDay = normalizeDayKey(day);
    if (!normalizedDay) return;
    mappedScores[normalizedDay] = extractScore(value);
  });

  const ordered = DAY_ORDER.map((day) => ({
    name: DAY_LABELS[day],
    value: mappedScores[day] ?? 0,
  }));

  return ordered.some((d) => d.value !== 0) ? ordered : EMPTY_CHART;
};

const Dashboard = () => {
  const token = localStorage.getItem("accessToken");
  const [fullName, setFullName] = useState("");
  const [typedName, setTypedName] = useState("");
  const [typingIndex, setTypingIndex] = useState(0);
  const [mountContent, setMountContent] = useState(false);
  const [moveTop, setMoveTop] = useState(false);
  const [showContent, setShowContent] = useState(false);
  const [isProfileLoaded, setIsProfileLoaded] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [score, setScore] = useState(0);
  const [analysisHistory, setAnalysisHistory] = useState([]);

  useEffect(() => {
    const authHeaders = { Authorization: `Bearer ${token}` };
    const controller = new AbortController();
    let isActive = true;

    fetch("http://localhost:8080/user/profile", {
      headers: authHeaders,
      signal: controller.signal,
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("Profile fetch failed"))))
      .then((data) => {
        if (!isActive) return;
        setFullName(`${data.firstName || ""} ${data.lastName || ""}`.trim());
        setTypedName("");
        setTypingIndex(0);
        setMountContent(false);
        setMoveTop(false);
        setShowContent(false);
      })
      .catch((error) => {
        if (!isActive || error.name === "AbortError") return;
        setFullName("");
        setTypedName("");
        setTypingIndex(0);
        setMountContent(false);
        setMoveTop(false);
        setShowContent(false);
      })
      .finally(() => {
        if (isActive) setIsProfileLoaded(true);
      });
      
    fetch("http://localhost:8080/analysis/latest", {
      headers: authHeaders,
      signal: controller.signal,
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("Analysis fetch failed"))))
      .then((data) => {
        if (!isActive) return;
        const normalized = normalizeAnalysis(data);
        setAnalysis(normalized);
        setScore(normalized?.overAllScore ?? 0);
        setChartData(buildChartData(normalized?.daily));
      })
      .catch((error) => {
        if (!isActive || error.name === "AbortError") return;
        setAnalysis(null);
        setScore(0);
        setChartData(EMPTY_CHART);
      });

    fetch("http://localhost:8080/analysis/all", {
      headers: authHeaders,
      signal: controller.signal,
    })
      .then((res) => (res.ok ? res.json() : []))
      .then((data) => {
        if (!isActive) return;
        setAnalysisHistory(
          Array.isArray(data) ? data.map((item) => normalizeAnalysis(item)).filter(Boolean) : []
        );
      })
      .catch((error) => {
        if (!isActive || error.name === "AbortError") return;
        setAnalysisHistory([]);
      });

     
      

    return () => {
      isActive = false;
      controller.abort();
    };
  }, [token]);

  useEffect(() => {
    if (!isProfileLoaded) return;

    const targetName = fullName || "there";
    let typingTimeout;
    let moveTimeout;
    let mountTimeout;
    let contentTimeout;

    if (typingIndex < targetName.length) {
      typingTimeout = setTimeout(() => {
        setTypedName((prev) => prev + targetName[typingIndex]);
        setTypingIndex((prev) => prev + 1);
      }, 50);
    } else {
      moveTimeout = setTimeout(() => setMoveTop(true), 300);
      mountTimeout = setTimeout(() => setMountContent(true), 700);
      contentTimeout = setTimeout(() => setShowContent(true), 700);
    }

    return () => {
      clearTimeout(typingTimeout);
      clearTimeout(moveTimeout);
      clearTimeout(mountTimeout);
      clearTimeout(contentTimeout);
    };
  }, [typingIndex, fullName, isProfileLoaded]);

  const chartSummary = useMemo(() => {
    if (!chartData.length) {
      return { best: { name: "N/A", value: 0 }, low: { name: "N/A", value: 0 } };
    }

    const best = chartData.reduce((max, item) =>
      item.value > max.value ? item : max
    );
    const low = chartData.reduce((min, item) =>
      item.value < min.value ? item : min
    );
    return { best, low };
  }, [chartData]);

  const patternsObserved = formatText(analysis?.patternsObserved);
  const nextWeekExperiments = formatText(analysis?.nextWeekExperiments);
  const showAnimatedWelcome = isProfileLoaded;
  const showStaticWelcome = showContent;

  const getScoreGrade = (value) => {
    const scoreValue = Number(value) || 0;
    if (scoreValue >= 80) return "green";
    if (scoreValue >= 60) return "yellow";
    if (scoreValue >= 40) return "brown";
    return "red";
  };

  return (
    <div className={`dashboard-main-anim-wrapper ${mountContent ? "content-mounted" : "intro-active"}`}>
      {showAnimatedWelcome && (
        <div
          className={`dashboard-main-welcome ${moveTop ? "top" : "center"}`}
        >
          Welcome, {typedName}
          <span className="dashboard-main-cursor">|</span>
        </div>
      )}

      {mountContent && (
        <div className={`dashboard-main-content ${showContent ? "show" : ""}`}>
          <div className="dashboard-page">
            <header className="dashboard-title">
              <p>Track your emotions. Discover patterns. Grow every week.</p>
            </header>

            <section className="dashboard-main-grid">
              <div className="dashboard-left-col">
                <MoodScoreCard score={score} />

                <div className="dashboard-card chart-card">
                  <h3>Mood Analytics (This Week)</h3>

                  <ResponsiveContainer width="100%" height={220}>
                    <LineChart data={chartData}>
                      <CartesianGrid stroke="#d9deea" strokeDasharray="4 4" />
                      <XAxis dataKey="name" tick={{ fill: "#5f6778", fontSize: 14 }} />
                      <YAxis
                        domain={[0, 100]}
                        tick={{ fill: "#5f6778", fontSize: 14 }}
                        width={32}
                      />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#6b93c6"
                        strokeWidth={3}
                        dot={{ fill: "#dfe8f5", stroke: "#5d86bd", strokeWidth: 2, r: 5 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>

                  <p className="chart-summary">
                    Best day: {chartSummary.best.name} ({chartSummary.best.value}) . Lowest day:{" "}
                    {chartSummary.low.name} ({chartSummary.low.value})
                  </p>

                  <div className="week-strip">
                    {chartData.map((day) => (
                      <div key={day.name} className={`week-pill week-pill-${getScoreGrade(day.value)}`}>
                        <span>{day.name}</span>
                        <strong>{day.value}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="dashboard-card insights-card">
                <h3>AI Weekly Insights</h3>
                <p className="insight-title">What affected you this week</p>
                <p className="insight-copy">
                  {analysis?.personalReflection || "No insights yet for this week."}
                </p>

                <div className="insight-block focus">
                  <h4>Focus for Improvement</h4>
                  <p>{patternsObserved || "Write a few entries this week to get specific guidance."}</p>
                </div>

                <div className="insight-block next-step">
                  <h4>One thing to try next week</h4>
                  <p>
                    {nextWeekExperiments ||
                      "Pick one small routine and follow it daily for seven days."}
                  </p>
                </div>
              </div>
            </section>

            <section className="dashboard-card previous-analysis">
              <div className="previous-header">
                <h3>Previous Weekly Analysis</h3>
              </div>

              <div className="analysis-list">
                {analysisHistory.slice(0, 3).map((item, idx) => (
                  <div key={`${item.createdAt || "analysis"}-${idx}`} className="analysis-row">
                    <span>
                      {item.createdAt ? new Date(item.createdAt).toLocaleDateString() : "Unknown date"}
                    </span>
                    <span>Score: {item.overAllScore ?? 0} -&gt;</span>
                  </div>
                ))}

                {!analysisHistory.length && (
                  <div className="analysis-row empty">No previous weekly analysis available yet.</div>
                )}
              </div>
            </section>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
