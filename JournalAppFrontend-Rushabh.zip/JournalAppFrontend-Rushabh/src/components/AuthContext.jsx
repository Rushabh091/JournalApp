import { createContext, useContext, useEffect, useState } from "react";
import { login as loginApi } from "../api/authService";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    const username = localStorage.getItem("username");

    if (token && username) {
      setUser({ username });
    }

    setLoading(false);
  }, []);

  const login = async (credentials) => {
    const data = await loginApi(credentials);
    setUser({ username: data.username });
  };

  const logout = () => {
    localStorage.clear();
    setUser(null);
    window.location.href = "/signin";
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
