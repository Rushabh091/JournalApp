import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import "./MoodChart.css";

const dataSets = {
  week: [
    { name: "Mon", value: 60 },
    { name: "Tue", value: 72 },
    { name: "Wed", value: 55 },
    { name: "Thu", value: 80 },
    { name: "Fri", value: 78 },
    { name: "Sat", value: 90 },
    { name: "Sun", value: 85 },
  ],
  month: [
    { name: "Week 1", value: 65 },
    { name: "Week 2", value: 70 },
    { name: "Week 3", value: 75 },
    { name: "Week 4", value: 82 },
  ],
  year: [
    { name: "Jan", value: 60 },
    { name: "Mar", value: 68 },
    { name: "May", value: 72 },
    { name: "Jul", value: 80 },
    { name: "Sep", value: 77 },
    { name: "Nov", value: 85 },
  ],
};

const MoodChart = () => {
  const [range, setRange] = useState("week");

  return (
    <div className="chart-card">
      <div className="chart-header">
        <h3>Mood Analytics</h3>

        <div className="filters">
          {["week", "month", "year"].map((item) => (
            <button
              key={item}
              className={range === item ? "active" : ""}
              onClick={() => setRange(item)}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={dataSets[range]}>
          <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#007aff"
            strokeWidth={3}
            dot={{ r: 4 }}
            activeDot={{ r: 7 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MoodChart;
