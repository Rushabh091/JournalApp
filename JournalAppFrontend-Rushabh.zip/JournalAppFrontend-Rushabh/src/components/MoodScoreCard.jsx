import React from "react";
import "./MoodScoreCard.css";

const getMood = (score) => {
  if (score >= 80) {
    return {
      emoji: "\uD83D\uDE04 \uD83C\uDF1F",
      label: "Great Week",
      type: "great",
    };
  }

  if (score >= 60) {
    return {
      emoji: "\uD83D\uDE42 \uD83C\uDF24\uFE0F",
      label: "Moderate Week",
      type: "moderate",
    };
  }

  if (score >= 40) {
    return {
      emoji: "\uD83D\uDE15 \uD83C\uDF42",
      label: "Needs Attention",
      type: "attention",
    };
  }

  return {
    emoji: "\uD83D\uDE1E \uD83C\uDF27\uFE0F",
    label: "Challenging Week",
    type: "challenging",
  };
};

const MoodScoreCard = ({ score = 0 }) => {
  const mood = getMood(score);

  return (
    <div className={`mood-card ${mood.type}`}>
      <h3 className="mood-title">🧠 Emotional Health - This Week</h3>

      <div className="mood-body">
        <div className="score-box">
          <span className="score">{score}</span>
          <span className="outof">/100</span>
        </div>

        <div className="mood-text">
          <div className="emoji">
            <span>{mood.emoji}</span>
            <span className="label">{mood.label}</span>
          </div>
          <p className="caption">Compared to your recent emotional patterns</p>
        </div>
      </div>
    </div>
  );
};

export default MoodScoreCard;
