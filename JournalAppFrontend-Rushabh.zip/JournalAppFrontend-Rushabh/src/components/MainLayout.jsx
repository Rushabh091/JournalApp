import { Layout, Menu, Button, Tooltip } from "antd";
import { Outlet, useLocation, useNavigate } from "react-router-dom";


import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  LogoutOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { AiOutlineDashboard, AiOutlineFileText, AiOutlineUser } from "react-icons/ai";
import { useEffect, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import "./MainLayout.css"; 

const { Header, Sider, Content } = Layout;

const MainLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [isMobileViewport, setIsMobileViewport] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { logout } = useAuth();
  // store user name in state so we can update it when we fetch the profile
  const [userName, setUserName] = useState("");

  const handleLogout = () => {
    logout();
    navigate("/signin");
  };

  // compute initials from whatever name we currently have
  const initials = (userName || "US").slice(0, 2).toUpperCase();

  const selectedKey = location.pathname.startsWith("/entries")
    ? "/entries"
    : location.pathname.startsWith("/journals")
    ? "/journals"
    : location.pathname.startsWith("/profile")
    ? "/profile"
    : "/";

  useEffect(() => {
    // if there's no token we can't be authenticated
    const accessToken = localStorage.getItem("accessToken");
    if (!accessToken) {
      navigate("/signin");
      return;
    }
    const controller = new AbortController();
    fetch("http://localhost:8080/user/profile", {
      headers: { Authorization: `Bearer ${accessToken}` },
      signal: controller.signal,
    })
      .then((res) =>
        res.ok ? res.json() : Promise.reject(new Error("Profile fetch failed"))
      )
      .then((data) => {
        const full = `${data.firstName || ""} ${data.lastName || ""}`.trim();
        if (full) {
          setUserName(full);
        }
      })
      .catch((err) => {
        if (err.name === "AbortError") return;
        setUserName("");
      });

    return () => controller.abort();
  }, [navigate]);

  useEffect(() => {
    const mobileMedia = window.matchMedia("(max-width: 991px)");
    const laptopMedia = window.matchMedia("(max-width: 1280px)");

    const apply = () => {
      const isMobile = mobileMedia.matches;
      const isLaptop = laptopMedia.matches;
      setIsMobileViewport(isMobile);
      setCollapsed(isMobile || isLaptop);
    };

    apply();

    const handler = () => apply();
    if (mobileMedia.addEventListener && laptopMedia.addEventListener) {
      mobileMedia.addEventListener("change", handler);
      laptopMedia.addEventListener("change", handler);
      return () => {
        mobileMedia.removeEventListener("change", handler);
        laptopMedia.removeEventListener("change", handler);
      };
    }

    mobileMedia.addListener(handler);
    laptopMedia.addListener(handler);
    return () => {
      mobileMedia.removeListener(handler);
      laptopMedia.removeListener(handler);
    };
  }, []);

  useEffect(() => {
    if (!isMobileViewport) {
      document.body.style.overflow = "";
      return undefined;
    }

    document.body.style.overflow = collapsed ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileViewport, collapsed]);

  return (
    <Layout className="app-layout">
      <Sider
        collapsible
        collapsed={collapsed}
        trigger={null}
        className={`app-sider ${isMobileViewport ? "app-sider-mobile" : ""}`}
        width={230}
        collapsedWidth={isMobileViewport ? 0 : 72}
      >
        <div className="sider-logo">
          <h2>{collapsed ? "KA" : "Keeper App"}</h2>
        </div>

        <div className="sider-menu">
          <Menu
            theme="dark"
            mode="inline"
            selectedKeys={[selectedKey]}
            onClick={({ key }) => {
              navigate(key);
              if (isMobileViewport) {
                setCollapsed(true);
              }
            }}
            items={[
              { key: "/", icon: <AiOutlineDashboard />, label: "Dashboard" },
              {
                key: "/journals",
                icon: <AiOutlineFileText />,
                label: "Add Journal",
              },
              {
                key: "/entries",
                icon: <AiOutlineUser />,
                label: "All Entries",
              },
              {
                key: "/profile",
                icon: <UserOutlined />,
                label: "Profile",
              },
        
            ]}
          />
        </div>

        <div className="sider-logout">
          <Button
            danger
            block
            icon={<LogoutOutlined />}
            onClick={handleLogout}
          >
            {!collapsed && "Logout"}
          </Button>
        </div>
      </Sider>
      {isMobileViewport && !collapsed && (
        <button
          type="button"
          className="app-sider-backdrop"
          aria-label="Close navigation"
          onClick={() => setCollapsed(true)}
        />
      )}

      <Layout>
        <Header className="app-header">
          <div className="header-left">
            <div
              className="collapse-trigger"
              onClick={() => setCollapsed(!collapsed)}
              role="button"
              tabIndex={0}
              aria-label={collapsed ? "Open navigation" : "Close navigation"}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  setCollapsed((prev) => !prev);
                }
              }}
            >
              {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            </div>
          </div>

          <div className="header-right">
            <button type="button" className="week-chip">
              Week of Jan 22 - Jan 28
            </button>
            <Tooltip placement="bottom" title={userName}>
              <div
                className="profile-chip"
                role="button"
                tabIndex={0}
                onClick={() => navigate("/profile")}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    navigate("/profile");
                  }
                }}
              >
                {initials}
              </div>
            </Tooltip>
          </div>
        </Header>

        <Content className="app-content">
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
};

export default MainLayout;
