import { Card, Flex } from "antd";
import "./AuthLayout.css";

const AuthLayout = ({ children, cardClassName = "", cardMaxWidth = 520 }) => {
  return (
    <Flex justify="center" align="center" className="auth-layout">
      <Card
        className={`auth-card ${cardClassName}`.trim()}
        style={{ maxWidth: cardMaxWidth, width: "100%" }}
      >
        {children}
      </Card>
    </Flex>
  );
};

export default AuthLayout;
