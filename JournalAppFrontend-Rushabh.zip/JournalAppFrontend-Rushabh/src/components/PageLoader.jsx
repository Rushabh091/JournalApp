import React from "react";
import "./PageLoader.css";

const PageLoader = ({ minHeight = 300 }) => {
  return (
    <div className="loader-wrapper" style={{ minHeight }}>
      <div className="loader" />
    </div>
  );
};

export default PageLoader;
