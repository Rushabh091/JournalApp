import zxcvbn from "zxcvbn";

const PasswordStrength = ({ password }) => {
  if (!password) return null;

  const result = zxcvbn(password);
  const score = result.score;

  const labels = ["Very Weak", "Weak", "Okay", "Strong", "Very Strong"];
  const colors = ["#ff4d4f", "#fa8c16", "#fadb14", "#1890ff", "#52c41a"];

  return (
    <div style={{ marginTop: 6 }}>
      <div style={{ height: 6, background: "#f0f0f0", borderRadius: 4 }}>
        <div
          style={{
            width: `${(score + 1) * 20}%`,
            height: "100%",
            background: colors[score],
            borderRadius: 4,
            transition: "0.3s",
          }}
        />
      </div>
      <small style={{ color: colors[score] }}>
        Strength: {labels[score]}
      </small>
    </div>
  );
};

export default PasswordStrength;
