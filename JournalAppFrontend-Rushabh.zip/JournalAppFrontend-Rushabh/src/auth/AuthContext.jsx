import { createContext, useContext, useEffect, useState } from "react";
import axios from "axios";

const AuthContext = createContext(null);

const API = axios.create({
  baseURL: "http://localhost:8080",
});



API.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

API.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;

    if (error.response?.status === 403 && !original._retry) {
      original._retry = true;

      try {
        const refreshToken = localStorage.getItem("refreshToken");

        const { data } = await axios.post(
          "http://localhost:8080/public/refresh-token",
          { refreshToken }
        );

        localStorage.setItem("accessToken", data.accessToken);
        localStorage.setItem("refreshToken", data.refreshToken);

        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return API(original);
      } catch {
        localStorage.clear();
        window.location.href = "/signin";
      }
    }

    return Promise.reject(error);
  }
);


export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    const username = localStorage.getItem("username");
    if (token && username) setUser({ username });
    setLoading(false);
  }, []);


  const login = async ({ userNameOrEmail, password }) => {
    const { data } = await axios.post("http://localhost:8080/public/login", {
      userNameOrEmail,
      password,
    });

    localStorage.setItem("accessToken", data.accessToken);
    localStorage.setItem("refreshToken", data.refreshToken);
    localStorage.setItem("username", data.username);

    setUser({ username: data.username });
    return data;
  };

  const logout = () => {
    localStorage.clear();
    setUser(null);
  };

  const sendForgotOtp = (email) => {
    return axios.post("http://localhost:8080/public/send-otp", { email });
  };

  const verifyForgotOtp = (email, otp) => {
    return axios.post("http://localhost:8080/public/otp-verify", { email, otp });
  };

  const changePassword = (email, newPassword) => {
    return axios.post("http://localhost:8080/public/change-password", {
      email,
      newPassword,
    });
  };

  const sendSignupOtp = (email) => {
    return axios.post("http://localhost:8080/public/signup/send-otp", { email });
  };

  const verifySignupOtp = (email, otp) => {
    return axios.post("http://localhost:8080/public/signup/verify-otp", {
      email,
      otp,
    });
  };

  const signup = (payload) => {
  return axios.post("http://localhost:8080/public/signup", payload);
};


  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAuthenticated: !!user,

        login,
        logout,
        signup,

        sendForgotOtp,
        verifyForgotOtp,
        changePassword,

        sendSignupOtp,
        verifySignupOtp,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
